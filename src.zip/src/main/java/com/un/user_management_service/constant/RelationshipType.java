package com.un.user_management_service.constant;

public enum RelationshipType {
    SPOUSE, CHILD, PARENT, SIBLING, GUARDIAN, OTHER
}
