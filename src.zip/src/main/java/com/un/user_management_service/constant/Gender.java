package com.un.user_management_service.constant;

public enum Gender {
    MALE, FEMALE, OTHER, PREFER_NOT_TO_SAY
}
