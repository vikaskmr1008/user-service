package com.un.user_management_service.constant;

public enum AddressType {
    HOME, WORK, BILLING, SHIPPING, TEMPORARY
}