package com.un.user_management_service.constant;

public enum EntityType {
    USER, CONTRACT
}