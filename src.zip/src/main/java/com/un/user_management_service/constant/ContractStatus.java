package com.un.user_management_service.constant;

public enum ContractStatus {
 DRAFT, ACTIVE, SUSPENDED, EXPIRED, TERMINATED, CANCELLED   
}