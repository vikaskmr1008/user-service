package com.un.user_management_service.constant;

public enum ContractType {
    EMPLOYMENT, SERVICE, INSURANCE, PARTNERSHIP, CONSULTING
}